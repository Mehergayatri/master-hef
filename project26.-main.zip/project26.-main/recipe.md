1. Peel the potatoes, then, cut each potato lengthwise into 4 or 5 pieces, then cut each piece into sticks. Each stick should be about 1cm (1/2-inch) thick.

2. Rinse potatoes under cold water, then place potatoes in a large bowl and cover with water. Let soak for 30 minutes.

3. Pat dry with a clean kitchen towel.

4. Heat oil in a deep-fryer or large saucepan to 275-300F (135-150C).

5. Gently add the potatoes to the oil, in batches, and fry for about 3-5 minutes, until soft, but not golden, stirring and flipping the potatoes occasionally. Remove from oil and drain on a paper towel. Let cool.

6. At this stage you can freeze the potatoes and keep them until ready for use.

7. Heat oil to 400F (200C). Fry the potatoes again, in batches, until golden brown, about 7-8 minutes.

8. Remove from oil, transfer to a paper towel to drain. Season with salt and pepper.

9. Serve with ketchup and mayonnaise.