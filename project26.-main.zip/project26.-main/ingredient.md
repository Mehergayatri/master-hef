INGREDIENTS
4 large  potatoes
Oil for frying
Salt and pepper for seasoning
Cold water
Ketchup
Mayonnaise