This recipe is about how to make french fries 
this method is the par fry method which makes fries more crispy 
the other is par boil method but the fries turn out to be soggy